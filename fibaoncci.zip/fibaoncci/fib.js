
alert("PLease enter 10 digits: ");
let array=[];
for(let i=0;i<10;i++){
  let a=prompt("Enter number : " + (i+1) + " : " )
  array.push(a);
}

document.write("The numbers are : " + array + "</br>");
let sum=parseInt(array[0])+parseInt(array[1])+ parseInt(array[2]) + parseInt(array[3])+
  parseInt(array[4])+parseInt(array[5])+parseInt(array[6])+parseInt(array[7])
    +parseInt(array[8])+parseInt(array[9]);
document.write("The fibanocci series is : " + sum);